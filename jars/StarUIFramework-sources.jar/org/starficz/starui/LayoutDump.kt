package org.starficz.starui

import com.fs.starfarer.api.ui.*
import org.starficz.starui.layout.NodeSize
import org.starficz.starui.modifier.actual
import org.starficz.starui.modifier.PaddingValues
import org.starficz.starui.runtime.childNode
import org.starficz.starui.runtime.nodeOf
import org.starficz.starui.runtime.StarUIPanelPlugin

/**
 * Returns the UI tree below this component as indented text, one line per component: what it is, its text, its
 * size, its position relative to this component's top left corner (x to the right, y downwards, the way layouts are
 * written), how StarUI sizes it, and which modifiers and reactive scope are attached.
 *
 * It is meant for debugging layouts without a screenshot, for tests, and for AI agents that cannot see the screen:
 *
 * ```
 * Column 150x80 at (40, 40) size=(wrap, wrap) [onRenderBelow] scope(builds=2, reads=1)
 *   Text "state B" 52x15 at (0, 0) size=(wrap, wrap)
 *   Spacer 100x20 at (0, 20) size=(exact 100, exact 20) [onRenderBelow]
 * ```
 *
 * A Holo's content (a Dialog's window content too) is listed under its holo, though the holo holds it outside its
 * children.
 *
 * The sizes and positions are the current ones: call it after a frame has rendered, or the layout has not run yet.
 */
fun UIComponentAPI.dumpLayout(): String {
    val root = this.actual
    val out = StringBuilder()
    dumpNode(root, root, null, 0, out)
    return out.toString()
}

private fun dumpNode(node: UIComponentAPI, root: UIComponentAPI, parentPlugin: StarUIPanelPlugin?, depth: Int, out: StringBuilder) {
    val plugin = StarUIPanelPlugin.getAttached(node)
    // a scrolling container: its vanilla scroll panel is the node, and the StarUI container inside it is described
    // on the same line (overflow, content size, scroll offset, padding, scope) with its children below
    val inner = plugin?.scrollContent
    val position = node.position
    val rootPosition = root.position
    val left = position.x - rootPosition.x
    val top = (rootPosition.y + rootPosition.height) - (position.y + position.height)

    val childNode = nodeOf(node)
    repeat(depth) { out.append("  ") }
    out.append(childNode?.record?.kind ?: plugin?.kind ?: fallbackKind(node))
    textOf(node)?.let { text ->
        out.append(" \"").append(if (text.length > 40) text.take(37) + "..." else text).append('"')
    }
    out.append(' ').append(number(position.width)).append('x').append(number(position.height))
    out.append(" at (").append(number(left)).append(", ").append(number(top)).append(')')

    // the size rule its container lays it out by, or a top-level node's own
    val sizing = childNode?.size?.takeIf { parentPlugin?.layoutEngine != null || plugin?.isTopLevelNode == true }
    if (sizing != null) out.append(" size=").append(describe(sizing))
    val overflowOf = inner ?: plugin
    if (overflowOf != null && overflowOf.overflow != Overflow.Visible) out.append(" overflow=").append(overflowOf.overflow)
    if (inner != null && node is ScrollPanelAPI) {
        val c = inner.component.position
        out.append(" content=").append(number(c.width)).append('x').append(number(c.height))
        if (node.xOffset != 0f || node.yOffset != 0f) {
            out.append(" offset=(").append(number(-node.xOffset)).append(", ").append(number(node.yOffset)).append(')')
        }
    }
    // a scrolling container's padding is on the StarUI container inside its scroll panel
    val padding = (inner?.node ?: childNode)?.padding?.takeIf { it != PaddingValues.Zero }
    padding?.let { p ->
        out.append(" padding=(").append(number(p.left)).append(", ").append(number(p.top)).append(", ")
            .append(number(p.right)).append(", ").append(number(p.bottom)).append(')')
    }
    childNode?.margin?.takeIf { it != PaddingValues.Zero }?.let { m ->
        out.append(" margin=(").append(number(m.left)).append(", ").append(number(m.top)).append(", ")
            .append(number(m.right)).append(", ").append(number(m.bottom)).append(')')
    }
    if (plugin != null) {
        val handlers = plugin.describeHandlers()
        if (handlers.isNotEmpty()) out.append(" [").append(handlers).append(']')
        (inner ?: plugin).scope?.let { scope ->
            out.append(" scope(builds=").append(scope.buildCount)
            if (scope.isReactive) out.append(", reactive")
            if (scope.dirty) out.append(", dirty")
            out.append(')')
        }
        if (plugin.isDisposed) out.append(" DISPOSED")
    }
    out.append('\n')

    // the same children findAll walks: panels, scroll content, a Holo's content held outside the tree
    walkChildrenOf(node, plugin) { child, childPlugin -> dumpNode(child, root, childPlugin, depth + 1, out) }
}

private fun describe(size: NodeSize): String = "(" + describe(size.width) + ", " + describe(size.height) + ")"

private fun describe(dimension: Axis): String = when (dimension) {
    is Axis.Exact -> "exact " + number(dimension.pixels)
    is Axis.FillMax -> if (dimension.weight == 1f) "fill" else "fill " + number(dimension.weight)
    Axis.WrapContent -> "wrap"
    AspectRatioAxis -> "aspect"
}

private fun number(value: Float): String =
    if (value == Math.round(value).toFloat()) Math.round(value).toString() else String.format(java.util.Locale.ROOT, "%.1f", value)
